

public class Driver {

	public static void main(String[] args) {
		System.out.println("Java Stock Exchange");
		new Controller();
		
	}

}
