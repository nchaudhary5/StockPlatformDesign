

import java.util.AbstractCollection;
import java.util.*;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Controller {
	
	public Controller() {
		LinkedList<Stock> googList = new LinkedList<Stock>();
		LinkedList<Stock> amazList = new LinkedList<Stock>();

		Scanner input = new Scanner(System.in);
		
		do {
			
			System.out.print("Type the stock name you wish to buy and sell or quit(Google or Amazon): ");
			String stockName = input.nextLine().toUpperCase();
			if(stockName.equals("QUIT")) break;
			
			System.out.print("Input 1 to buy, 2 to sell: ");
			int controlNum = input.nextInt();
			if(controlNum == 1) {
				System.out.print("How many stocks: ");
				int quantity = input.nextInt();
				System.out.print("At what price: ");
				double price = input.nextDouble();
				if(stockName.equals("GOOGLE")) {
					Controller.buyStock(googList, "Google", quantity, price);
				}
				if(stockName.equals("AMAZON")) {
					Controller.buyStock(amazList, "Amazon", quantity, price);
				}
			}
			
			if(controlNum ==2) {
				System.out.print("Press 1 for LIFO accounting, 2 for FIFO accounting: ");
				controlNum = input.nextInt();
				System.out.print("How many stocks: ");
				int quantity = input.nextInt();
				if(controlNum ==1) {
					if(stockName.equals("GOOGLE")) {
						Controller.sellLIFO(googList, quantity);
					}
					if(stockName.equals("AMAZON")) {
						Controller.sellLIFO(amazList, quantity);
				   }
				}
				if(controlNum == 2) {
					if(stockName.equals("GOOGLE")) {
						Controller.sellFIFO(googList, quantity);
					}
					if(stockName.equals("AMAZON")) {
						Controller.sellFIFO(amazList, quantity);
				}
			}
			}
		//clears buffer for next loop
		input.nextLine();
		} while(true);
		input.close();
	}
			
	public static void buyStock(LinkedList<Stock> list, String name, int quantity, double price) {
		Stock temp = new Stock(name,quantity,price);
		list.push(temp);
		System.out.printf("You bought %d shares of %s stock at $%.2f per share %n", quantity, name, price);
	}
	
	public static void sellLIFO(LinkedList<Stock> list, int numToSell) {
		//Checks if linked list is empty
		if(list.isEmpty()) {
			System.out.println("You don't have any stock to sell.\n");
		}
		//This loop will iterate through the list and count all the stocks the user owns, the same loop is in sellFIFO
		double stockVal=0;
		int stockAmount=0;
	    double averagePrice=0;
		int listSize = list.size();
		//I count up the linked list stocks from the tail of the list and push on to the head as i pop off the tail with pollLast()
		//Since the linked list will contain negative stock quantity as sold, the stockVal is calculated based on the average price of the bought stock
		//This first loop checks to see if the user has stock to sell and updates the average price of bought stock
		for(int i=0;i<listSize;i++) {
		    stockAmount+= list.peekLast().getQuantity();
		    if(list.peekLast().getQuantity()>0) {
		    	stockVal += (list.peekLast().getQuantity()*list.peekLast().getPrice());
		    }else {
		    	stockVal += (list.peekLast().getQuantity()*averagePrice);
		    }
			Stock temp = new Stock(list.peekLast().getName(),list.peekLast().getQuantity(),list.peekLast().getPrice());
			list.pollLast();
			list.push(temp);
		}
		averagePrice = stockVal/stockAmount;
		//check to see if there is  enough stock to sell
		if(numToSell>stockAmount) {
			System.out.println(("You can't sell more stock than you own!\nYou currently have: " + stockAmount+ "\n" +
		"Your stock is valued at: $" + stockVal + "\n"));
		}else {
		    // You need to write the code to sell the stock using the LIFO method (Stack)
		    // You also need to calculate the profit/loss on the sale
		    double total = 0; // this variable will store the total after the sale
		    double profit = 0; // the price paid minus the sale price, negative # means a loss
		    double sellPrice=0; //price to be sold at
		    double balance=0;
		    boolean negativeP = false;

		    Scanner input = new Scanner(System.in);
		    System.out.println("Enter the selling price per share: ");
		    sellPrice = input.nextDouble();
		    String name = list.element().getName();//name of current stock
		    //This conditional checks to see if the user will net profit or net loss
		    if(sellPrice<list.element().getPrice()) {
				   negativeP=true;
			   }
		    total=numToSell*sellPrice;
		    balance = sellPrice-list.element().getPrice();;//since the linked list appends to the stack in order, the last link in is the first one out
		    profit = numToSell*balance;//I am basing profit on how much more or less was sold per share based on last buy
		    
		    //This updates my stock holdings and value in the linked list
		    Stock sold = new Stock(name,(~(numToSell-1)),sellPrice);
		    list.push(sold);
		    
		    //This updates user Stock Portfolio and uses the updated averagePrice from the first loop to calculate user stock value
		    stockAmount=0;
		    stockVal=0;
		    listSize=list.size();
			for(int i=0;i<listSize;i++) {
			    stockAmount+= list.peekLast().getQuantity();
			    if(list.peekLast().getQuantity()>0) {
			    	stockVal += (list.peekLast().getQuantity()*list.peekLast().getPrice());
			    }else {
			    	stockVal += (list.peekLast().getQuantity()*averagePrice);
			    }
				Stock temp = new Stock(list.peekLast().getName(),list.peekLast().getQuantity(),list.peekLast().getPrice());
				list.pollLast();
				list.push(temp);
			}
			averagePrice = stockVal/stockAmount;
			System.out.printf("You sold %d shares of %s stock at %.2f per share %n", numToSell, name, total/numToSell);
		    System.out.printf("You made $%.2f on the sale %n", total);
		    if(negativeP==false) {
			    System.out.printf("Thats a profit of $%.2f %n", profit);
		    }else {
			    System.out.printf("Thats a loss of -$%.2f %n", profit);
		    }
		    System.out.println("Your Stock Total: " + stockAmount);
		    System.out.printf("Your Stock Value: $%.2f %n", stockVal);
		   // input.close();
		    }
}

	
	public static void sellFIFO(LinkedList<Stock> list, int numToSell) {
		//checks if linked list is empty
		if(list.isEmpty()) {
			System.out.println("You don't have any stock to sell.\n");
		}
		double stockVal=0;
		int stockAmount=0;
		double averagePrice=0;
		int listSize = list.size();
		//same loop as LIFO to count up the stocks
		for(int i=0;i<listSize;i++) {
		    stockAmount+= list.peekLast().getQuantity();
		    if(list.peekLast().getQuantity()>0) {
		    	stockVal += (list.peekLast().getQuantity()*list.peekLast().getPrice());
		    }else {
		    	stockVal += (list.peekLast().getQuantity()*averagePrice);
		    }
		    
			Stock temp = new Stock(list.peekLast().getName(),list.peekLast().getQuantity(),list.peekLast().getPrice());
			list.pollLast();
			list.push(temp);
		}
		averagePrice = stockVal/stockAmount;
		//checks if user has enough stocks to sell
		if(numToSell>stockAmount) {
			System.out.println(("You can't sell more stock than you own!\nYou currently have: " + stockAmount+ "\n" +
		"Your stock is valued at: $" + stockVal + "\n"));
		}else {
		    // You need to write the code to sell the stock using the FIFO method (Queue)
		    // You also need to calculate the profit/loss on the sale
		    double total = 0; // this variable will store the total after the sale
		    double profit = 0; // the price paid minus the sale price, negative # means a loss
		    double sellPrice = 0;//price for stock to be sold at
		    double balance = 0;
		    boolean negativeP = false;
		    String name = list.element().getName();//name of current stock
		   
		    Scanner input = new Scanner(System.in);
		    System.out.println("Enter the selling price per share: ");
		   sellPrice = input.nextDouble();
		   if(sellPrice<list.peekLast().getPrice()) {
			   negativeP=true;
		   }
		   balance = sellPrice-list.peekLast().getPrice();//since the linked list appends to the stack in order, the first link in will be the first one out in this case
		   total=numToSell*sellPrice;
		   profit = numToSell*balance;
		 //This updates my stock holdings and value in the linked list
		   Stock sold = new Stock(name,(~(numToSell-1)),sellPrice);
		   list.push(sold);
		   
		    stockAmount=0;
		    stockVal=0;
		    listSize=list.size();
			for(int i=0;i<listSize;i++) {
			    stockAmount+= list.peekLast().getQuantity();
			    if(list.peekLast().getQuantity()>0) {
			    	stockVal += (list.peekLast().getQuantity()*list.peekLast().getPrice());
			    }else {
			    	stockVal += (list.peekLast().getQuantity()*averagePrice);
			    }
				Stock temp2 = new Stock(list.peekLast().getName(),list.peekLast().getQuantity(),list.peekLast().getPrice());
				list.pollLast();
				list.push(temp2);
			}
			averagePrice = stockVal/stockAmount;
			System.out.printf("You sold %d shares of %s stock at %.2f per share %n", numToSell, name, total/numToSell);
		    System.out.printf("You made $%.2f on the sale %n", total);	
		    if(negativeP==false) {
			    System.out.printf("Thats a profit of $%.2f %n", profit);
		    }else {
			    System.out.printf("Thats a loss of -$%.2f %n", profit);
		    }
		    System.out.println("Your Stock Total: " + stockAmount);
		    System.out.printf("Your Stock Value: $%.2f %n", stockVal);
		   // input.close();
		}

	}
	
}
